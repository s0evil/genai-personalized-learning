..
   Note: Items in this toctree form the top-level navigation. See `api.rst` for the `autosummary` directive, and for why `api.rst` isn't called directly.

Table of Contents
=================

.. toctree::
   :maxdepth: 2

   Home page <readme_link>
   Contribution Guide <contributing_link>
   Code Documentation <_autosummary/generative_data_prep>

Sambanova Generative Data Preparation
=====================================
Welcome to the Sambanova Generative Data Preparation documentation.
