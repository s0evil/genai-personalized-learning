.. include:: ../../.github/CONTRIBUTING.rst
