#!/usr/bin/env bash

find scripts -name "*.sh" -exec shellcheck {} +

